package app.processmanager;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Btn1Activity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 这就是那个新按钮专属的文字和图片
        TextView tv = new TextView(this);
        tv.setText("这是全新的按钮1功能！\n它的代码完全独立，互不干扰！");
        tv.setTextSize(24);
        tv.setPadding(40, 40, 40, 40);
        setContentView(tv);
    }
}
