package app.processmanager;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class NewFeaturesActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);

        TextView tv = new TextView(this);
        tv.setText("这里是全新的独立模块！\n\n以后所有的超长代码、新功能按钮，全部写在这个文件里，主程序的代码再也不会乱了。");
        tv.setTextSize(16f);
        tv.setPadding(0, 0, 0, 40);
        layout.addView(tv);

        Button btnDemo = new Button(this);
        btnDemo.setText("这是一个新模块里的测试按钮");
        btnDemo.setOnClickListener(v -> Toast.makeText(this, "新模块运行正常！", Toast.LENGTH_SHORT).show());
        layout.addView(btnDemo);

        Button btnBack = new Button(this);
        btnBack.setText("返回主页");
        btnBack.setOnClickListener(v -> finish());
        layout.addView(btnBack);

        setContentView(layout);
    }
}
