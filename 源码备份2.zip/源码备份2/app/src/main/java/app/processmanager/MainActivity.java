package app.processmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private ListView listView;
    private TextView tvTopStatus, tvTerminalOutput, tvModel, tvKernel, tvSysInfo, tvCardStatusTitle, tvCardStatusDesc, tvCardIcon;
    private EditText etTerminalInput;
    private View tab_home, tab_features, tab_security, tab_settings;
    private View panel_magisk, panel_system, panel_memory, panel_risk, layout_list_container, layout_cpu, layout_terminal;
    private LinearLayout cpuContainer;
    private Button nav_home, nav_features, nav_security, nav_settings;

    // 安全页面控件
    private TextView tvSecEmoji, tvSecTitle, tvSecDesc, tvSecFingerprint, tvSecPatch, tvSecRoot, tvSecXposed, tvSecBl;

    private List<AppItem> dataList = new ArrayList<>();
    private PackageManager pm;
    private AppAdapter adapter;
    private boolean isProcessLoading = false, hasRoot = false;
    private Map<String, Drawable> iconCache = new HashMap<>();

    class AppItem {
        String name, packageOrPid, sourceDir;
        boolean isProcess, isSystem;
        AppItem(String name, String packageOrPid, boolean isProcess, boolean isSystem, String sourceDir) {
            this.name = name; this.packageOrPid = packageOrPid;
            this.isProcess = isProcess; this.isSystem = isSystem; this.sourceDir = sourceDir;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        listView = findViewById(R.id.listView);
        tvTopStatus = findViewById(R.id.tv_top_status);
        tvCardStatusTitle = findViewById(R.id.tv_card_status_title);
        tvCardStatusDesc = findViewById(R.id.tv_card_status_desc);
        tvCardIcon = findViewById(R.id.tv_card_icon);
        tvModel = findViewById(R.id.tv_device_model);
        tvKernel = findViewById(R.id.tv_kernel_version);
        tvSysInfo = findViewById(R.id.tv_sys_info);
        
        tab_home = findViewById(R.id.tab_home);
        tab_features = findViewById(R.id.tab_features);
        tab_security = findViewById(R.id.tab_security);
        tab_settings = findViewById(R.id.tab_settings);
        
        panel_magisk = findViewById(R.id.panel_magisk);
        panel_system = findViewById(R.id.panel_system);
        panel_memory = findViewById(R.id.panel_memory);
        panel_risk = findViewById(R.id.panel_risk);
        layout_list_container = findViewById(R.id.layout_list_container);
        layout_cpu = findViewById(R.id.layout_cpu);
        layout_terminal = findViewById(R.id.layout_terminal);
        
        cpuContainer = findViewById(R.id.cpu_container);
        tvTerminalOutput = findViewById(R.id.tv_terminal_output);
        etTerminalInput = findViewById(R.id.et_terminal_input);
        
        nav_home = findViewById(R.id.nav_home);
        nav_features = findViewById(R.id.nav_features);
        nav_security = findViewById(R.id.nav_security);
        nav_settings = findViewById(R.id.nav_settings);

        // 安全页面控件绑定
        tvSecEmoji = findViewById(R.id.tv_sec_emoji);
        tvSecTitle = findViewById(R.id.tv_sec_title);
        tvSecDesc = findViewById(R.id.tv_sec_desc);
        tvSecFingerprint = findViewById(R.id.tv_sec_fingerprint);
        tvSecPatch = findViewById(R.id.tv_sec_patch);
        tvSecRoot = findViewById(R.id.tv_sec_root);
        tvSecXposed = findViewById(R.id.tv_sec_xposed);
        tvSecBl = findViewById(R.id.tv_sec_bl);

        pm = getPackageManager();
        tvModel.setText(Build.BRAND + " " + Build.MODEL);
        tvKernel.setText(System.getProperty("os.version") + " (" + Build.CPU_ABI + ")");
        tvSysInfo.setText("Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")");
        
        checkRootStatus();

        nav_home.setOnClickListener(v -> switchTab(0));
        nav_features.setOnClickListener(v -> switchTab(1));
        nav_security.setOnClickListener(v -> {
            switchTab(2);
            runSecurityCheck(); // 点击安全页时执行真实检测
        });
        nav_settings.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SettingsActivity.class)));

        // 图标点击
        findViewById(R.id.iv_tw_1).setOnClickListener(v -> openUrl("https://twitter.com"));
        findViewById(R.id.iv_gh_1).setOnClickListener(v -> openUrl("https://github.com/danwan-dev/process_manager"));
        findViewById(R.id.layout_download_link).setOnClickListener(v -> openUrl("https://github.com/danwan-dev/process_manager"));
        findViewById(R.id.iv_tw_download).setOnClickListener(v -> openUrl("https://twitter.com"));
        findViewById(R.id.iv_gh_download).setOnClickListener(v -> openUrl("https://github.com/danwan-dev/process_manager"));

        // 跳转
        findViewById(R.id.btn_open_f1).setOnClickListener(v -> switchSubPanel(1));
        findViewById(R.id.btn_open_f2).setOnClickListener(v -> switchSubPanel(2));
        findViewById(R.id.btn_open_adjust).setOnClickListener(v -> switchSubPanel(3));
        findViewById(R.id.btn_open_f3).setOnClickListener(v -> switchSubPanel(4));
        findViewById(R.id.btn_open_applist).setOnClickListener(v -> switchSubPanel(5));
        findViewById(R.id.btn_open_terminal).setOnClickListener(v -> switchSubPanel(6));
        findViewById(R.id.btn_open_new_1).setOnClickListener(v -> startActivity(new Intent(MainActivity.this, Btn1Activity.class)));
        
        // 返回
        findViewById(R.id.btn_back_f1).setOnClickListener(v -> switchTab(1));
        findViewById(R.id.btn_back_f2).setOnClickListener(v -> switchTab(1));
        findViewById(R.id.btn_back_adjust).setOnClickListener(v -> switchTab(1));
        findViewById(R.id.btn_back_f3).setOnClickListener(v -> switchTab(1));
        findViewById(R.id.btn_back_applist).setOnClickListener(v -> switchTab(1));
        findViewById(R.id.btn_back_cpu).setOnClickListener(v -> switchTab(1));
        findViewById(R.id.btn_back_terminal).setOnClickListener(v -> switchTab(1));

        // 功能绑定
        findViewById(R.id.btn_module).setOnClickListener(v -> selectFile(100, "application/zip"));
        findViewById(R.id.btn_module_list).setOnClickListener(v -> showModuleList());
        findViewById(R.id.btn_extract_boot).setOnClickListener(v -> extractBootImage());
        findViewById(R.id.btn_battery).setOnClickListener(v -> checkBatteryHealth());
        findViewById(R.id.btn_spoof).setOnClickListener(v -> showInputDialog("更改机型", "输入机型", "resetprop ro.product.model '"));
        findViewById(R.id.btn_disable_update).setOnClickListener(v -> disableSystemUpdates());
        findViewById(R.id.btn_resolution).setOnClickListener(v -> showResolutionDialog());
        findViewById(R.id.btn_hide_status).setOnClickListener(v -> execCmd("settings put global policy_control immersive.status=*", "已开启状态栏沉浸"));
        findViewById(R.id.btn_fps).setOnClickListener(v -> showInputDialog("改帧率(Hz)", "输入 90 或 120", "FPS_FAKE"));
        findViewById(R.id.btn_adblock).setOnClickListener(v -> setupAdBlock());
        findViewById(R.id.btn_sys_file).setOnClickListener(v -> selectFile(102, "*/*"));
        findViewById(R.id.btn_cpu).setOnClickListener(v -> switchSubPanel(7));
        findViewById(R.id.btn_max_power).setOnClickListener(v -> forceMaxPower());
        findViewById(R.id.btn_temp).setOnClickListener(v -> showInputDialog("温度欺骗(℃)", "输入如: 35", "TEMP_FAKE"));
        findViewById(R.id.btn_regulator).setOnClickListener(v -> showInputDialog("CPU电压", "输入如: 800", "REGULATOR_FAKE"));
        findViewById(R.id.btn_ram_fake).setOnClickListener(v -> showInputDialog("内存分配(MB)", "输入如: 8192", "RAM_FAKE"));
        findViewById(R.id.btn_storage_fake).setOnClickListener(v -> showInputDialog("存储容量(GB)", "输入如: 512", "STORAGE_FAKE"));
        findViewById(R.id.btn_format).setOnClickListener(v -> showFormatWarning());
        findViewById(R.id.btn_terminal_run).setOnClickListener(v -> runTerminalCmd());

        switchTab(0); 
        loadAppsOnly();
        loadProcessesInBackground();
        listView.setOnItemClickListener((parent, view, position, id) -> showAppMenu(dataList.get(position)));
    }

    // ================= 真实安全检测逻辑 (Momo 低配版) =================
    private void runSecurityCheck() {
        tvSecFingerprint.setText(Build.FINGERPRINT);
        tvSecPatch.setText(Build.VERSION.SECURITY_PATCH);

        new Thread(() -> {
            boolean isRooted = false;
            boolean isXposed = false;
            boolean isUnlocked = false;

            // 1. 检测 Root (文件 + 命令)
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"which", "su"});
                if (p.waitFor() == 0) isRooted = true;
            } catch (Exception ignored) {}
            
            String[] paths = {"/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk", "/data/adb/magisk"};
            for (String path : paths) {
                if (new File(path).exists()) { isRooted = true; break; }
            }

            // 2. 检测 Xposed/LSPosed
            try {
                throw new Exception("Check");
            } catch (Exception e) {
                for (StackTraceElement element : e.getStackTrace()) {
                    if (element.getClassName().contains("de.robv.android.xposed") || element.getClassName().contains("org.lsposed")) {
                        isXposed = true; break;
                    }
                }
            }
            // 检查包名
            try {
                pm.getPackageInfo("de.robv.android.xposed.installer", 0);
                pm.getPackageInfo("org.lsposed.manager", 0);
                isXposed = true;
            } catch (Exception ignored) {}

            // 3. 检测 Bootloader 状态
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"getprop", "ro.boot.verifiedbootstate"});
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String state = r.readLine();
                if (state != null && (state.contains("orange") || state.contains("yellow"))) {
                    isUnlocked = true;
                } else if (Build.TAGS != null && Build.TAGS.contains("test-keys")) {
                    isUnlocked = true;
                }
            } catch (Exception ignored) {}

            final boolean finalRoot = isRooted;
            final boolean finalXposed = isXposed;
            final boolean finalUnlocked = isUnlocked;

            runOnUiThread(() -> {
                // 更新卡片文字
                if (finalRoot) tvSecRoot.setText("\nRoot 检测: 发现 Root 痕迹 (su文件或Magisk目录)");
                else tvSecRoot.setText("\nRoot 检测: 环境正常 (未发现 su)");

                if (finalXposed) tvSecXposed.setText("\nLSPosed 检测: 发现 Xposed/LSPosed 框架");
                else tvSecXposed.setText("\nLSPosed 检测: 环境正常");

                if (finalUnlocked) tvSecBl.setText("\nBootloader 状态: 已解锁 (存在风险)");
                else tvSecBl.setText("\nBootloader 状态: 已锁定 (正常)");

                // 顶部笑脸状态变化
                if (finalRoot || finalXposed || finalUnlocked) {
                    tvSecEmoji.setText("X"); tvSecEmoji.setTextColor(0xFFF44336);
                    tvSecTitle.setText("环境异常");
                    tvSecDesc.setText("发现系统或环境已被修改");
                } else {
                    tvSecEmoji.setText("√"); tvSecEmoji.setTextColor(0xFF4CAF50);
                    tvSecTitle.setText("环境正常");
                    tvSecDesc.setText("没有发现对环境的修改");
                }
            });
        }).start();
    }

    private void switchTab(int tabIndex) {
        tab_home.setVisibility(tabIndex == 0 ? View.VISIBLE : View.GONE);
        tab_features.setVisibility(tabIndex == 1 ? View.VISIBLE : View.GONE);
        tab_security.setVisibility(tabIndex == 2 ? View.VISIBLE : View.GONE);
        tab_settings.setVisibility(tabIndex == 3 ? View.VISIBLE : View.GONE);
        
        panel_magisk.setVisibility(View.GONE); panel_system.setVisibility(View.GONE); panel_memory.setVisibility(View.GONE); panel_risk.setVisibility(View.GONE); layout_list_container.setVisibility(View.GONE); layout_cpu.setVisibility(View.GONE); layout_terminal.setVisibility(View.GONE);
        
        nav_home.setTextColor(tabIndex == 0 ? 0xFF000000 : 0xFF888888);
        nav_features.setTextColor(tabIndex == 1 ? 0xFF000000 : 0xFF888888);
        nav_security.setTextColor(tabIndex == 2 ? 0xFF000000 : 0xFF888888);
        nav_settings.setTextColor(tabIndex == 3 ? 0xFF000000 : 0xFF888888);
    }

    private void switchSubPanel(int panelIndex) {
        tab_home.setVisibility(View.GONE); tab_features.setVisibility(View.GONE); tab_security.setVisibility(View.GONE); tab_settings.setVisibility(View.GONE);
        panel_magisk.setVisibility(panelIndex == 1 ? View.VISIBLE : View.GONE);
        panel_system.setVisibility(panelIndex == 2 ? View.VISIBLE : View.GONE);
        panel_memory.setVisibility(panelIndex == 3 ? View.VISIBLE : View.GONE);
        panel_risk.setVisibility(panelIndex == 4 ? View.VISIBLE : View.GONE);
        layout_list_container.setVisibility(panelIndex == 5 ? View.VISIBLE : View.GONE);
        layout_terminal.setVisibility(panelIndex == 6 ? View.VISIBLE : View.GONE);
        layout_cpu.setVisibility(panelIndex == 7 ? View.VISIBLE : View.GONE);
        if (panelIndex == 7) loadCpuCores();
    }

    private void checkRootStatus() {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line = r.readLine();
                hasRoot = line != null && line.contains("uid=0");
            } catch (Exception e) { hasRoot = false; }
            runOnUiThread(() -> {
                if (hasRoot) {
                    tvTopStatus.setText("已激活"); tvTopStatus.setTextColor(0xFF4CAF50);
                    tvCardStatusTitle.setText("已激活"); tvCardStatusTitle.setTextColor(0xFF4CAF50);
                    tvCardStatusDesc.setText("进程管理器正在工作中");
                    tvCardIcon.setText("✔️"); tvCardIcon.setTextColor(0xFF4CAF50);
                } else {
                    tvTopStatus.setText("未激活"); tvTopStatus.setTextColor(0xFFF44336);
                    tvCardStatusTitle.setText("未激活"); tvCardStatusTitle.setTextColor(0xFFF44336);
                    tvCardStatusDesc.setText("缺少 Root 权限");
                    tvCardIcon.setText("✘"); tvCardIcon.setTextColor(0xFFF44336);
                }
            });
        }).start();
    }

    private void openUrl(String url) {
        try { 
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); 
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
            startActivity(intent); 
        } catch (Exception e) { 
            Toast.makeText(this, "无法打开浏览器", Toast.LENGTH_SHORT).show(); 
        }
    }

    private void showInputDialog(String title, String hint, final String cmdPrefix) {
        final EditText et = new EditText(this); et.setHint(hint);
        new AlertDialog.Builder(this).setTitle(title).setView(et).setPositiveButton("执行", (d, w) -> {
            String val = et.getText().toString().trim(); if (val.isEmpty()) return;
            if (cmdPrefix.equals("TEMP_FAKE")) execCmd("mount -o rw,remount /sys; for f in /sys/class/thermal/thermal_zone*/temp; do echo " + (Integer.parseInt(val)*1000) + " > $f; done; mount -o ro,remount /sys", "已伪装温度");
            else if (cmdPrefix.equals("FPS_FAKE")) execCmd("settings put system min_refresh_rate " + val + " && settings put system peak_refresh_rate " + val, "已改帧率");
            else if (cmdPrefix.equals("REGULATOR_FAKE")) execCmd("for f in /sys/class/regulator/regulator.*/microamps; do echo " + val + " > $f; done", "已尝试调节电压");
            else if (cmdPrefix.equals("RAM_FAKE")) execCmd("setprop dalvik.vm.heapsize " + val + "m", "已改内存");
            else if (cmdPrefix.equals("STORAGE_FAKE")) execCmd("setprop ro.product.storage_size " + val + "GB", "已改存储");
            else execCmd(cmdPrefix + val + "'", "已执行");
        }).setNegativeButton("取消", null).show();
    }

    private void checkBatteryHealth() {
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            try {
                Process pDump = Runtime.getRuntime().exec(new String[]{"su", "-c", "dumpsys batterystats 2>/dev/null | grep -E 'Capacity|Estimated' | head -n 5"});
                BufferedReader rDump = new BufferedReader(new InputStreamReader(pDump.getInputStream()));
                String dumpLine;
                while ((dumpLine = rDump.readLine()) != null) { if (dumpLine.contains("Capacity") || dumpLine.contains("Estimated")) sb.append(dumpLine.trim()).append("\n"); }
            } catch (Exception e) { sb.append("读取异常。"); }
            runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("电池健康度").setMessage(sb.toString()).setPositiveButton("OK", null).show());
        }).start();
    }

    private void showFormatWarning() {
        final EditText et = new EditText(this); et.setHint("输入 YES 确认");
        new AlertDialog.Builder(this).setTitle("⚠️ 极度危险 ⚠️").setMessage("将清空 /data 分区！").setView(et)
            .setPositiveButton("确认", (d, w) -> { if ("YES".equals(et.getText().toString().trim())) execCmd("sync && rm -rf /data/*", "自毁指令已执行"); })
            .setNegativeButton("取消", null).show();
    }

    private void forceMaxPower() {
        execCmd("mount -o rw,remount /sys; for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo performance > $cpu/cpufreq/scaling_governor 2>/dev/null; done; mount -o ro,remount /sys", "已尝试满血调度");
    }

    private void showModuleList() {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "ls /data/adb/modules"});
                BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line; final List<String> mods = new ArrayList<>();
                while ((line = reader.readLine()) != null) { line = line.trim(); if (!line.isEmpty() && !line.equals("lost+found")) mods.add(line); }
                p.waitFor();
                runOnUiThread(() -> {
                    if (mods.isEmpty()) Toast.makeText(this, "没有模块", Toast.LENGTH_SHORT).show();
                    else new AlertDialog.Builder(this).setTitle("已安装模块").setItems(mods.toArray(new String[0]), (d, w) -> {}).show();
                });
            } catch (Exception e) {}
        }).start();
    }

    private void extractBootImage() {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "mkdir -p /sdcard/Download/BootBackup && dd if=/dev/block/by-name/boot of=/sdcard/Download/BootBackup/boot.img"});
                final int res = p.waitFor();
                runOnUiThread(() -> Toast.makeText(this, res == 0 ? "提取成功: Download/BootBackup" : "提取失败", Toast.LENGTH_LONG).show());
            } catch (Exception e) {}
        }).start();
    }

    private void disableSystemUpdates() {
        execCmd("pm disable-user --user 0 com.android.updater; pm disable-user --user 0 com.huawei.android.hwouc", "已尝试冻结系统更新");
    }

    private void setupAdBlock() {
        execCmd("mount -o rw,remount /; echo '127.0.0.1 doubleclick.net' > /system/etc/hosts; mount -o ro,remount /", "已开启Hosts拦截");
    }

    private void showResolutionDialog() {
        final EditText et = new EditText(this); et.setHint("输入如: 1080x1920");
        new AlertDialog.Builder(this).setTitle("调节分辨率").setView(et)
            .setPositiveButton("修改", (d, w) -> execCmd("wm size " + et.getText().toString(), "已修改"))
            .setNeutralButton("恢复默认", (d, w) -> execCmd("wm size reset", "已恢复")).setNegativeButton("取消", null).show();
    }

    private void selectFile(int reqCode, String type) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT); intent.setType(type); startActivityForResult(intent, reqCode);
    }

    private void execCmd(final String cmd, final String msg) {
        new Thread(() -> {
            try {
                Runtime.getRuntime().exec(new String[]{"su", "-c", cmd}).waitFor();
                runOnUiThread(() -> { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); loadAppsOnly(); loadProcessesInBackground(); });
            } catch (Exception e) {}
        }).start();
    }

    private void runTerminalCmd() {
        String cmd = etTerminalInput.getText().toString().trim(); if (cmd.isEmpty()) return;
        tvTerminalOutput.append("\n$ " + cmd + "\n"); etTerminalInput.setText("");
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line; final StringBuilder sb = new StringBuilder();
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
                p.waitFor();
                runOnUiThread(() -> tvTerminalOutput.append(sb.toString()));
            } catch (Exception e) {}
        }).start();
    }

    private void loadProcessesInBackground() {
        if (isProcessLoading) return; isProcessLoading = true;
        new Thread(() -> {
            try {
                Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "ps -A -o pid,name"});
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line; final List<AppItem> newProcs = new ArrayList<>();
                while ((line = reader.readLine()) != null) {
                    line = line.trim(); if (line.isEmpty() || line.startsWith("PID")) continue;
                    String[] parts = line.split("\\s+"); if (parts.length >= 2) {
                        String pid = parts[0], pName = parts[1]; boolean exists = false;
                        for (AppItem item : dataList) if (!item.isProcess && item.packageOrPid.equals(pName)) { exists = true; break; }
                        if (!exists && !pName.equals("ps")) newProcs.add(new AppItem(pName, pid, true, false, null));
                    }
                }
                reader.close(); process.waitFor();
                runOnUiThread(() -> { dataList.addAll(newProcs); sortAndRefresh(); isProcessLoading = false; });
            } catch (Exception e) { isProcessLoading = false; }
        }).start();
    }

    private void loadAppsOnly() {
        new Thread(() -> {
            List<AppItem> apps = new ArrayList<>();
            for (ApplicationInfo appInfo : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
                apps.add(new AppItem(appInfo.loadLabel(pm).toString(), appInfo.packageName, false, (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0, appInfo.sourceDir));
            }
            runOnUiThread(() -> { dataList.clear(); dataList.addAll(apps); sortAndRefresh(); });
        }).start();
    }

    private void sortAndRefresh() {
        Collections.sort(dataList, (a, b) -> a.name.compareToIgnoreCase(b.name));
        if (adapter == null) { adapter = new AppAdapter(); listView.setAdapter(adapter); } else adapter.notifyDataSetChanged();
    }

    private void showAppMenu(final AppItem item) {
        if (item.isProcess) {
            new AlertDialog.Builder(this).setTitle(item.name).setItems(new String[]{"🔴 强杀该进程"}, (d, w) -> execCmd("kill -9 " + item.packageOrPid, "已强杀")).show();
            return;
        }
        String[] ops = new String[]{"🔴 强杀", "❄️ 冻结", "🔥 解冻", "💾 备份", "💣 静默卸载", "💥 物理删除", "♻️ 恢复"};
        new AlertDialog.Builder(this).setTitle(item.name).setItems(ops, (d, w) -> {
            switch (w) {
                case 0: execCmd("am force-stop " + item.packageOrPid, "已强杀"); break;
                case 1: execCmd("pm disable-user --user 0 " + item.packageOrPid, "已冻结"); break;
                case 2: execCmd("pm enable " + item.packageOrPid, "已解冻"); break;
                case 3: if (item.sourceDir != null) execCmd("cp " + item.sourceDir + " /sdcard/Download/backup_" + item.packageOrPid + ".apk", "已备份"); break;
                case 4: execCmd("pm uninstall --user 0 " + item.packageOrPid, "已卸载"); break;
                case 5: if (item.sourceDir != null) execCmd("mount -o rw,remount /; rm -rf '" + item.sourceDir + "'; mount -o ro,remount /", "已物理删除"); break;
                case 6: execCmd("pm install-existing " + item.packageOrPid, "已恢复"); break;
            }
        }).show();
    }

    private void loadCpuCores() {
        cpuContainer.removeAllViews();
        for (int i = 0; i < 8; i++) {
            final int idx = i;
            Button btn = new Button(this); btn.setText("CPU" + idx + " 切换");
            btn.setOnClickListener(v -> new Thread(() -> {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "cat /sys/devices/system/cpu/cpu" + idx + "/online"});
                    boolean isOn = !"0".equals(new BufferedReader(new InputStreamReader(p.getInputStream())).readLine().trim());
                    Runtime.getRuntime().exec(new String[]{"su", "-c", "echo " + (isOn ? "0" : "1") + " > /sys/devices/system/cpu/cpu" + idx + "/online"}).waitFor();
                    runOnUiThread(() -> Toast.makeText(this, "已切换", Toast.LENGTH_SHORT).show());
                } catch (Exception e) {}
            }).start());
            cpuContainer.addView(btn);
        }
    }

    class AppAdapter extends BaseAdapter {
        public int getCount() { return dataList.size(); }
        public Object getItem(int p) { return dataList.get(p); }
        public long getItemId(int p) { return p; }
        public View getView(int p, View v, ViewGroup g) {
            if (v == null) v = getLayoutInflater().inflate(R.layout.item_app, null);
            AppItem it = dataList.get(p);
            TextView n = v.findViewById(R.id.tv_app_name), pkg = v.findViewById(R.id.tv_package_name);
            ImageView ico = v.findViewById(R.id.iv_icon);
            n.setTextColor(0xFF000000); pkg.setTextColor(0xFF888888);
            if (it.isProcess) {
                n.setText("[进程] " + it.name); pkg.setText("PID: " + it.packageOrPid); ico.setImageResource(android.R.drawable.sym_def_app_icon);
            } else {
                Drawable icon = iconCache.get(it.packageOrPid);
                if (icon == null) { try { icon = pm.getApplicationIcon(it.packageOrPid); iconCache.put(it.packageOrPid, icon); } catch (Exception e) { icon = getResources().getDrawable(android.R.drawable.sym_def_app_icon); } }
                ico.setImageDrawable(icon);
                n.setText((it.isSystem ? "[系统] " : "") + it.name); pkg.setText(it.packageOrPid);
            }
            return v;
        }
    }
}
