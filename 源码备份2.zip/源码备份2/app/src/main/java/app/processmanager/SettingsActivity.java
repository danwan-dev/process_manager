package app.processmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;

public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);

        Button btnHideIcon = new Button(this);
        btnHideIcon.setText("隐藏桌面图标");
        btnHideIcon.setOnClickListener(v -> {
            new AlertDialog.Builder(this).setTitle("隐藏图标").setMessage("拨打 * # * # 9527 # * # * 可隐藏/显示图标").setPositiveButton("去拨号", (d,w) -> {
                try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:*#*#9527#*#*"))); } catch (Exception e) {}
            }).setNegativeButton("取消", null).show();
        });
        layout.addView(btnHideIcon);

        Button btnLog = new Button(this);
        btnLog.setText("查看终端错误日志");
        btnLog.setOnClickListener(v -> {
            try {
                File logFile = new File("/sdcard/Download/PM_Log.txt");
                if (!logFile.exists()) { Toast.makeText(this, "暂无报错日志", Toast.LENGTH_SHORT).show(); return; }
                FileInputStream fis = new FileInputStream(logFile);
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer); fis.close();
                String log = new String(buffer);
                new AlertDialog.Builder(this).setTitle("终端报错日志").setMessage(log).setPositiveButton("清空", (d, w) -> logFile.delete()).show();
            } catch (Exception e) { Toast.makeText(this, "读取失败", Toast.LENGTH_SHORT).show(); }
        });
        layout.addView(btnLog);

        setContentView(layout);
    }
}
