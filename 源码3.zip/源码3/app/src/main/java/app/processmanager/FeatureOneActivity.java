package app.processmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class FeatureOneActivity extends Activity {

    private TextView tvCurrentId;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feature_one);

        tvCurrentId = findViewById(R.id.tv_current_id);
        prefs = getSharedPreferences("device_id_prefs", MODE_PRIVATE);

        updateCurrentIdDisplay();

        // 1. 随机生成并修改
        findViewById(R.id.btn_random_id).setOnClickListener(v -> {
            String newId = generateRandomId();
            applyDeviceId(newId);
        });

        // 2. 应用自定义 ID
        EditText etCustomId = findViewById(R.id.et_custom_id);
        findViewById(R.id.btn_apply_custom).setOnClickListener(v -> {
            String customId = etCustomId.getText().toString().trim();
            if (customId.length() != 16) {
                Toast.makeText(this, "❌ 必须输入 16 位字符！", Toast.LENGTH_SHORT).show();
                return;
            }
            applyDeviceId(customId);
        });

        // 3. 恢复原始 ID
        findViewById(R.id.btn_restore_id).setOnClickListener(v -> {
            String originalId = prefs.getString("original_id", "");
            if (originalId.isEmpty()) {
                Toast.makeText(this, "❌ 没有找到原始 ID 记录！", Toast.LENGTH_SHORT).show();
                return;
            }
            applyDeviceId(originalId);
        });

        // 4. 针对指定应用重置
        EditText etPkg = findViewById(R.id.et_package_name);
        findViewById(R.id.btn_apply_to_pkg).setOnClickListener(v -> {
            String pkg = etPkg.getText().toString().trim();
            if (pkg.isEmpty()) {
                Toast.makeText(this, "请输入应用包名", Toast.LENGTH_SHORT).show();
                return;
            }
            // 利用 Root 强制停止并清除该应用数据，逼它重新读取新的设备 ID
            executeRootCommand("am force-stop " + pkg + " && pm clear " + pkg, "已强制重置应用: " + pkg);
        });
    }

    private void updateCurrentIdDisplay() {
        String currentId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        
        // 如果是第一次打开，记录下原本的 ID 用于恢复
        if (!prefs.contains("original_id")) {
            prefs.edit().putString("original_id", currentId).apply();
        }
        tvCurrentId.setText(currentId);
    }

    private String generateRandomId() {
        String chars = "0123456789abcdef";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    private void applyDeviceId(String newId) {
        // 修改底层 settings 数据库
        executeRootCommand("settings put secure android_id " + newId, null);
        
        // 更新显示
        tvCurrentId.setText(newId);
        
        // 弹出带有勾号的弹窗
        new AlertDialog.Builder(this)
                .setTitle("✅ 修改成功")
                .setMessage("您的设备 ID 已被修改为:\n\n" + newId + "\n\n(部分应用需重启手机或使用下方功能重置后生效)")
                .setPositiveButton("确定", null)
                .show();
    }

    private void executeRootCommand(String command, final String successMsg) {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", command});
                final int res = p.waitFor();
                runOnUiThread(() -> {
                    if (res == 0) {
                        if (successMsg != null) {
                            Toast.makeText(this, successMsg, Toast.LENGTH_SHORT).show();
                        }
                        updateCurrentIdDisplay();
                    } else {
                        Toast.makeText(this, "❌ Root 执行失败", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "执行异常，请检查 Root", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}
