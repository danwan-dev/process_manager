package app.processmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;

public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // 绑定控件
        Switch switchHideIcon = findViewById(R.id.switch_hide_icon);
        LinearLayout layoutShowLog = findViewById(R.id.layout_show_log);
        LinearLayout layoutOtherFeatures = findViewById(R.id.layout_other_features);
        
        PackageManager pm = getPackageManager();
        ComponentName componentName = new ComponentName(this, MainActivity.class);

        // 1. 初始化隐藏图标开关状态
        int state = pm.getComponentEnabledSetting(componentName);
        boolean isHidden = (state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED);
        switchHideIcon.setChecked(isHidden);

        // 2. 监听隐藏图标开关
        switchHideIcon.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
                Toast.makeText(this, "图标已隐藏，拨打 *#*#9527#*#* 恢复", Toast.LENGTH_LONG).show();
            } else {
                pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
                Toast.makeText(this, "图标已恢复", Toast.LENGTH_SHORT).show();
            }
        });

        // 3. 查看日志点击事件
        layoutShowLog.setOnClickListener(v -> {
            try {
                File logFile = new File("/sdcard/Download/PM_Log.txt");
                if (!logFile.exists()) {
                    Toast.makeText(this, "暂无报错日志", Toast.LENGTH_SHORT).show();
                    return;
                }
                FileInputStream fis = new FileInputStream(logFile);
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();
                String log = new String(buffer);
                new AlertDialog.Builder(this)
                        .setTitle("终端报错日志")
                        .setMessage(log)
                        .setPositiveButton("清空", (d, w) -> logFile.delete())
                        .setNegativeButton("关闭", null)
                        .show();
            } catch (Exception e) {
                Toast.makeText(this, "读取失败", Toast.LENGTH_SHORT).show();
            }
        });

        // 4. 【核心新增】跳转到修改设备 ID 页面的点击事件
        layoutOtherFeatures.setOnClickListener(v -> {
            startActivity(new Intent(SettingsActivity.this, FeatureOneActivity.class));
        });
    }
}
