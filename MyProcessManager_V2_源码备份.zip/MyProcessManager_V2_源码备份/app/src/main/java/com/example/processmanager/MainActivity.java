package com.example.processmanager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private ListView listView;
    private TextView tvStatus, tvTerminalOutput;
    private EditText etTerminalInput;
    private View layoutTerminal, layoutCpu, btnBackToList;
    private LinearLayout cpuContainer;
    private List<AppItem> dataList = new ArrayList<>();
    private PackageManager pm;
    private AppAdapter adapter;

    class AppItem {
        String name, packageOrPid, sourceDir;
        boolean isProcess, isSystem;
        AppItem(String name, String packageOrPid, boolean isProcess, boolean isSystem, String sourceDir) {
            this.name = name; this.packageOrPid = packageOrPid;
            this.isProcess = isProcess; this.isSystem = isSystem; this.sourceDir = sourceDir;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        tvStatus = findViewById(R.id.tv_status);
        layoutTerminal = findViewById(R.id.layout_terminal);
        layoutCpu = findViewById(R.id.layout_cpu);
        tvTerminalOutput = findViewById(R.id.tv_terminal_output);
        etTerminalInput = findViewById(R.id.et_terminal_input);
        cpuContainer = findViewById(R.id.cpu_container);
        btnBackToList = findViewById(R.id.btn_back_to_list);
        pm = getPackageManager();

        findViewById(R.id.btn_terminal).setOnClickListener(v -> switchMode(1));
        findViewById(R.id.btn_cpu).setOnClickListener(v -> switchMode(2));
        findViewById(R.id.btn_terminal_run).setOnClickListener(v -> runTerminalCmd());
        findViewById(R.id.btn_spoof).setOnClickListener(v -> showSpoofDialog());
        findViewById(R.id.btn_module).setOnClickListener(v -> selectModuleFile());
        findViewById(R.id.btn_battery).setOnClickListener(v -> checkBatteryHealth());
        btnBackToList.setOnClickListener(v -> switchMode(0));

        loadAppsOnly();
        loadProcessesInBackground();
        listView.setOnItemClickListener((parent, view, position, id) -> showAppMenu(dataList.get(position)));
    }

    private void switchMode(int mode) {
        listView.setVisibility(mode == 0 ? View.VISIBLE : View.GONE);
        layoutTerminal.setVisibility(mode == 1 ? View.VISIBLE : View.GONE);
        layoutCpu.setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
        btnBackToList.setVisibility(mode == 0 ? View.GONE : View.VISIBLE);
        if (mode == 2) loadCpuCores();
    }

    private void showSpoofDialog() {
        final EditText et = new EditText(this);
        et.setHint("输入新机型，如: Pixel 8 Pro");
        new AlertDialog.Builder(this).setTitle("更改机型 (resetprop)").setView(et)
                .setPositiveButton("修改", (d, w) -> {
                    String model = et.getText().toString().trim();
                    if (!model.isEmpty()) execCmd("resetprop ro.product.model '" + model + "'", "已伪装为: " + model);
                }).setNegativeButton("取消", null).show();
    }

    private void selectModuleFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/zip");
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            new AlertDialog.Builder(this).setTitle("刷入模块").setMessage("确定刷入该 ZIP 模块吗？")
                    .setPositiveButton("刷入", (d, w) -> installModuleFromUri(data.getData()))
                    .setNegativeButton("取消", null).show();
        }
    }

    private void installModuleFromUri(final Uri uri) {
        tvStatus.setText("复制模块中...");
        new Thread(() -> {
            try {
                File temp = new File(getCacheDir(), "module.zip");
                InputStream is = getContentResolver().openInputStream(uri);
                FileOutputStream fos = new FileOutputStream(temp);
                byte[] buf = new byte[8192]; int len;
                while ((len = is.read(buf)) > 0) fos.write(buf, 0, len);
                fos.close(); is.close();
                tvStatus.setText("调用 Magisk 刷入...");
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "magisk --install-module " + temp.getAbsolutePath()});
                final int res = p.waitFor();
                runOnUiThread(() -> {
                    if (res == 0) { Toast.makeText(this, "刷入成功！请重启", Toast.LENGTH_LONG).show(); tvStatus.setText("需重启"); }
                    else { Toast.makeText(this, "刷入失败", Toast.LENGTH_SHORT).show(); tvStatus.setText("失败"); }
                });
            } catch (Exception e) { runOnUiThread(() -> tvStatus.setText("出错")); }
        }).start();
    }

    private void checkBatteryHealth() {
        tvStatus.setText("读取电池...");
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            try {
                String[] paths = {"/sys/class/power_supply/battery/cycle_count", "/sys/class/power_supply/battery/charge_full", "/sys/class/power_supply/battery/charge_full_design"};
                String[] names = {"循环次数", "当前满电", "设计容量"};
                for (int i = 0; i < paths.length; i++) {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "cat " + paths[i]});
                    String line = new BufferedReader(new InputStreamReader(p.getInputStream())).readLine();
                    if (line != null && !line.trim().isEmpty()) sb.append(names[i]).append(": ").append(line.trim()).append("\n");
                }
                Process pF = Runtime.getRuntime().exec(new String[]{"su", "-c", "cat /sys/class/power_supply/battery/charge_full"});
                Process pD = Runtime.getRuntime().exec(new String[]{"su", "-c", "cat /sys/class/power_supply/battery/charge_full_design"});
                String fStr = new BufferedReader(new InputStreamReader(pF.getInputStream())).readLine();
                String dStr = new BufferedReader(new InputStreamReader(pD.getInputStream())).readLine();
                if (fStr != null && dStr != null) {
                    double health = (Double.parseDouble(fStr.trim()) / Double.parseDouble(dStr.trim())) * 100;
                    sb.append("\n👉 预估寿命: ").append(String.format("%.1f", health)).append("%");
                }
            } catch (Exception e) { sb.append("该机型节点未暴露或读取失败。"); }
            runOnUiThread(() -> {
                new AlertDialog.Builder(this).setTitle("电池健康度").setMessage(sb.toString()).setPositiveButton("OK", null).show();
                tvStatus.setText("就绪");
            });
        }).start();
    }
    private void loadAppsOnly() {
        dataList.clear();
        for (ApplicationInfo appInfo : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
            dataList.add(new AppItem(appInfo.loadLabel(pm).toString(), appInfo.packageName, false, (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0, appInfo.sourceDir));
        }
        sortAndRefresh("应用已加载");
    }

    private void loadProcessesInBackground() {
        new Thread(() -> {
            try {
                Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "ps -A -o pid,name"});
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line; int procCount = 0;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("PID")) continue;
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        String pid = parts[0], pName = parts[1];
                        boolean exists = false;
                        for (AppItem item : dataList) if (!item.isProcess && item.packageOrPid.equals(pName)) { exists = true; break; }
                        if (!exists && !pName.equals("ps")) { dataList.add(new AppItem(pName, pid, true, false, null)); procCount++; }
                    }
                }
                reader.close(); process.waitFor();
                final int fCount = procCount;
                runOnUiThread(() -> sortAndRefresh("进程 +" + fCount + "个"));
            } catch (Exception e) { runOnUiThread(() -> tvStatus.setText("未授权Root")); }
        }).start();
    }

    private void sortAndRefresh(String msg) {
        Collections.sort(dataList, (a, b) -> {
            if (a.isProcess != b.isProcess) return a.isProcess ? 1 : -1;
            if (a.isSystem != b.isSystem) return a.isSystem ? -1 : 1;
            return a.name.compareToIgnoreCase(b.name);
        });
        if (adapter == null) { adapter = new AppAdapter(); listView.setAdapter(adapter); } else adapter.notifyDataSetChanged();
        tvStatus.setText(msg + " | 共 " + dataList.size() + " 个");
    }

    private void showAppMenu(final AppItem item) {
        String[] ops = {"🔴 强杀", "❄️ 冻结", "🔥 解冻", "💾 备份", "🗑️ 卸载当前", "💣 彻底卸载", "♻️ 恢复", "🔑 授权"};
        new AlertDialog.Builder(this).setTitle(item.name).setItems(ops, (d, w) -> {
            switch (w) {
                case 0: execCmd(item.isProcess ? "kill -9 " + item.packageOrPid : "am force-stop " + item.packageOrPid, "已强杀"); break;
                case 1: execCmd("pm disable-user --user 0 " + item.packageOrPid, "已冻结"); break;
                case 2: execCmd("pm enable " + item.packageOrPid, "已解冻"); break;
                case 3: if (item.sourceDir != null) execCmd("cp " + item.sourceDir + " /sdcard/Download/" + item.name + ".apk", "已备份"); break;
                case 4: execCmd("pm uninstall --user 0 " + item.packageOrPid, "已卸载"); break;
                case 5: execCmd("pm uninstall " + item.packageOrPid, "已彻底卸载"); break;
                case 6: execCmd("pm install-existing " + item.packageOrPid, "已恢复"); break;
                case 7: execCmd("pm grant " + item.packageOrPid + " android.permission.WRITE_SECURE_SETTINGS", "已授权"); break;
            }
        }).show();
    }

    private void execCmd(final String cmd, final String msg) {
        new Thread(() -> {
            try {
                final int res = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd}).waitFor();
                runOnUiThread(() -> {
                    Toast.makeText(this, res == 0 ? msg : "失败", Toast.LENGTH_SHORT).show();
                    loadAppsOnly(); loadProcessesInBackground();
                });
            } catch (Exception e) {}
        }).start();
    }

    private void runTerminalCmd() {
        String cmd = etTerminalInput.getText().toString().trim();
        if (cmd.isEmpty()) return;
        tvTerminalOutput.append("\n$ " + cmd + "\n"); etTerminalInput.setText("");
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line; final StringBuilder sb = new StringBuilder();
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
                p.waitFor();
                runOnUiThread(() -> { tvTerminalOutput.append(sb.toString()); ((ScrollView)findViewById(R.id.sv_terminal)).fullScroll(View.FOCUS_DOWN); });
            } catch (Exception e) {}
        }).start();
    }

    private void loadCpuCores() {
        cpuContainer.removeAllViews();
        for (int i = 0; i < 8; i++) {
            final int idx = i;
            Button btn = new Button(this);
            btn.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            btn.setOnClickListener(v -> new Thread(() -> {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "cat /sys/devices/system/cpu/cpu" + idx + "/online"});
                    boolean isOn = !"0".equals(new BufferedReader(new InputStreamReader(p.getInputStream())).readLine().trim());
                    Runtime.getRuntime().exec(new String[]{"su", "-c", "echo " + (isOn ? "0" : "1") + " > /sys/devices/system/cpu/cpu" + idx + "/online"}).waitFor();
                    runOnUiThread(this::loadCpuCores);
                } catch (Exception e) {}
            }).start());
            cpuContainer.addView(btn);
            new Thread(() -> {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "cat /sys/devices/system/cpu/cpu" + idx + "/online"});
                    final boolean isOn = "1".equals(new BufferedReader(new InputStreamReader(p.getInputStream())).readLine().trim());
                    runOnUiThread(() -> { btn.setText("核心 CPU" + idx + " : " + (isOn ? "🟢 运行" : "🔴 关闭")); btn.setBackgroundColor(isOn ? 0xFFE8F5E9 : 0xFFFFEBEE); });
                } catch (Exception e) {}
            }).start();
        }
    }

    class AppAdapter extends BaseAdapter {
        public int getCount() { return dataList.size(); }
        public Object getItem(int p) { return dataList.get(p); }
        public long getItemId(int p) { return p; }
        public View getView(int p, View v, ViewGroup g) {
            if (v == null) v = getLayoutInflater().inflate(R.layout.item_app, null);
            AppItem it = dataList.get(p);
            TextView n = v.findViewById(R.id.tv_app_name), pkg = v.findViewById(R.id.tv_package_name);
            ImageView ico = v.findViewById(R.id.iv_icon);
            if (it.isProcess) {
                n.setTextColor(0xFF1976D2); n.setText("[进程] " + it.name); pkg.setText("PID: " + it.packageOrPid); ico.setImageResource(android.R.drawable.sym_def_app_icon);
            } else {
                try { ico.setImageDrawable(pm.getApplicationIcon(it.packageOrPid)); } catch (Exception e) { ico.setImageResource(android.R.drawable.sym_def_app_icon); }
                n.setTextColor(it.isSystem ? 0xFFD32F2F : 0xFF000000); n.setText((it.isSystem ? "[系统] " : "") + it.name); pkg.setText(it.packageOrPid);
            }
            return v;
        }
    }
}
