package app.processmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private ListView listView;
    private TextView tvStatus, tvTerminalOutput, tvSuStatus, tvRootLog;
    private EditText etTerminalInput;
    private View layoutTerminal, layoutCpu, panel_home;
    private LinearLayout cpuContainer;
    private List<AppItem> dataList = new ArrayList<>();
    private PackageManager pm;
    private AppAdapter adapter;
    private Uri pendingSysFileUri;
    private String pendingSysFilePath;
    private Map<String, Drawable> iconCache = new HashMap<>();
    private volatile boolean isFormatCancelled = false;
    private volatile boolean isProcessLoading = false;
    private boolean hasRoot = false;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    class AppItem {
        String name, packageOrPid, sourceDir;
        boolean isProcess, isSystem;
        AppItem(String name, String packageOrPid, boolean isProcess, boolean isSystem, String sourceDir) {
            this.name = name; this.packageOrPid = packageOrPid;
            this.isProcess = isProcess; this.isSystem = isSystem; this.sourceDir = sourceDir;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        tvStatus = findViewById(R.id.tv_status);
        tvSuStatus = findViewById(R.id.tv_su_status);
        tvRootLog = findViewById(R.id.tv_root_log);
        layoutTerminal = findViewById(R.id.layout_terminal);
        layoutCpu = findViewById(R.id.layout_cpu);
        panel_home = findViewById(R.id.panel_home);
        tvTerminalOutput = findViewById(R.id.tv_terminal_output);
        etTerminalInput = findViewById(R.id.et_terminal_input);
        cpuContainer = findViewById(R.id.cpu_container);
        pm = getPackageManager();

        checkRootStatus();

        findViewById(R.id.tab_magisk).setOnClickListener(v -> switchMode(1));
        findViewById(R.id.tab_system).setOnClickListener(v -> switchMode(2));
        findViewById(R.id.tab_memory).setOnClickListener(v -> switchMode(3));
        findViewById(R.id.tab_risk).setOnClickListener(v -> switchMode(4));
        findViewById(R.id.btn_device_info).setOnClickListener(v -> showDeviceInfo());
        findViewById(R.id.tab_main).setOnClickListener(v -> switchMode(5));

        findViewById(R.id.tv_download_link).setOnClickListener(v -> { 
            try { 
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wwbet.lanzouc.com/iF76M4chldmf")); 
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
                startActivity(i); 
            } catch (Exception e) { 
                Toast.makeText(this, "无法打开浏览器，请手动输入网址", Toast.LENGTH_SHORT).show(); 
            } 
        });

        findViewById(R.id.btn_module).setOnClickListener(v -> selectFile(100, "application/zip"));
        findViewById(R.id.btn_module_list).setOnClickListener(v -> showModuleList());
        findViewById(R.id.btn_extract_boot).setOnClickListener(v -> extractBootImage());
        findViewById(R.id.btn_sys_file).setOnClickListener(v -> selectFile(101, "*/*"));
        
        findViewById(R.id.btn_battery).setOnClickListener(v -> checkBatteryHealth());
        findViewById(R.id.btn_spoof).setOnClickListener(v -> showInputDialog("更改机型", "输入机型", "resetprop ro.product.model '"));
        findViewById(R.id.btn_disable_update).setOnClickListener(v -> disableSystemUpdates());
        findViewById(R.id.btn_resolution).setOnClickListener(v -> showResolutionDialog());
        findViewById(R.id.btn_hide_status).setOnClickListener(v -> toggleStatusBar());
        findViewById(R.id.btn_fps).setOnClickListener(v -> showInputDialog("改帧率(Hz)", "输入 90 或 120", "FPS_FAKE"));
        findViewById(R.id.btn_adblock).setOnClickListener(v -> setupAdBlock());

        findViewById(R.id.btn_cpu).setOnClickListener(v -> switchMode(6));
        findViewById(R.id.btn_max_power).setOnClickListener(v -> forceMaxPower());
        findViewById(R.id.btn_temp).setOnClickListener(v -> showInputDialog("温度欺骗(℃)", "输入如: 35", "TEMP_FAKE"));
        findViewById(R.id.btn_regulator).setOnClickListener(v -> showInputDialog("CPU电压", "输入如: 800", "REGULATOR_FAKE"));
        findViewById(R.id.btn_ram_fake).setOnClickListener(v -> showInputDialog("内存分配(MB)", "输入如: 8192", "RAM_FAKE"));
        findViewById(R.id.btn_storage_fake).setOnClickListener(v -> showInputDialog("存储容量(GB)", "输入如: 512", "STORAGE_FAKE"));

        findViewById(R.id.btn_format).setOnClickListener(v -> showFormatWarning());
        findViewById(R.id.btn_terminal_run).setOnClickListener(v -> runTerminalCmd());

        // 【新增】安全提示弹窗逻辑
        SharedPreferences prefs = getSharedPreferences("app_settings", MODE_PRIVATE);
        if (!prefs.getBoolean("is_warning_shown", false)) {
            new AlertDialog.Builder(this)
                .setTitle("安全提示")
                .setMessage("请从官方下载\n未知来源可能存在风险")
                .setPositiveButton("不再提示", (dialog, which) -> {
                    prefs.edit().putBoolean("is_warning_shown", true).apply();
                    dialog.dismiss();
                })
                .setNegativeButton("我知道了", (dialog, which) -> dialog.dismiss())
                .setCancelable(false)
                .show();
        }

        findViewById(R.id.btn_terminal_home).setOnClickListener(v -> switchMode(7));
        switchMode(0); 
        loadAppsOnly();
        loadProcessesInBackground();
        listView.setOnItemClickListener((parent, view, position, id) -> showAppMenu(dataList.get(position)));
    }

    private void checkRootStatus() {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line = r.readLine();
                hasRoot = line != null && line.contains("uid=0");
            } catch (Exception e) { hasRoot = false; }
            runOnUiThread(() -> {
                if (hasRoot) {
                    tvSuStatus.setText("状态: 🟢 高级权限已运行");
                    tvSuStatus.setTextColor(0xFF4CAF50);
                } else {
                    tvSuStatus.setText("状态: 🔵 普通模式");
                    tvSuStatus.setTextColor(0xFF2196F3);
                }
            });
        }).start();
    }

    private void showDeviceInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("品牌: ").append(Build.BRAND).append("\n");
        sb.append("型号: ").append(Build.MODEL).append("\n");
        sb.append("系统版本: ").append(Build.VERSION.RELEASE).append("\n");
        sb.append("SDK级别: ").append(Build.VERSION.SDK_INT).append("\n");
        sb.append("主板: ").append(Build.BOARD).append("\n");
        sb.append("硬件: ").append(Build.HARDWARE).append("\n");
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        sb.append("屏幕分辨率: ").append(displayMetrics.widthPixels).append("x").append(displayMetrics.heightPixels).append("\n");
        new AlertDialog.Builder(this).setTitle("设备信息").setMessage(sb.toString()).setPositiveButton("OK", null).show();
    }

    private void switchMode(int mode) {
        panel_home.setVisibility(mode == 0 ? View.VISIBLE : View.GONE);
        findViewById(R.id.panel_magisk).setVisibility(mode == 1 ? View.VISIBLE : View.GONE);
        findViewById(R.id.panel_system).setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
        findViewById(R.id.panel_memory).setVisibility(mode == 3 ? View.VISIBLE : View.GONE);
        findViewById(R.id.panel_risk).setVisibility(mode == 4 ? View.VISIBLE : View.GONE);
        listView.setVisibility(mode == 5 ? View.VISIBLE : View.GONE);
        layoutCpu.setVisibility(mode == 6 ? View.VISIBLE : View.GONE);
        layoutTerminal.setVisibility(mode == 7 ? View.VISIBLE : View.GONE);

        if (mode == 0) tvStatus.setText("极客控制台 (主菜单)");
        else if (mode == 5) tvStatus.setText("应用列表");
        
        if (mode == 6) loadCpuCores();
        if (mode == 5 && adapter != null) adapter.notifyDataSetChanged();
    }

    private void showAppMenu(final AppItem item) {
        if (item.isProcess) {
            new AlertDialog.Builder(this).setTitle(item.name)
                .setItems(new String[]{"🔴 强杀该进程"}, (d, w) -> execCmd("kill -9 " + item.packageOrPid, "已强杀进程")).show();
            return;
        }
        String[] ops = new String[]{"🔴 强杀/停止运行", "❄️ 冻结/停用", "🔥 解冻/启用", "💾 备份安装包", "💣 静默卸载 (需Root)", "💥 物理删除安装包 (需Root)", "♻️ 恢复系统应用", "🔑 授予高级权限", "🛠️ 逆向修改 (解压)"};
        
        new AlertDialog.Builder(this).setTitle(item.name).setItems(ops, (d, w) -> {
            switch (w) {
                case 0: 
                    new Thread(() -> {
                        try {
                            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "am force-stop " + item.packageOrPid + " ; kill -9 $(pidof " + item.packageOrPid + ")"});
                            if (p.waitFor() != 0) throw new Exception();
                            runOnUiThread(() -> Toast.makeText(this, "已强杀", Toast.LENGTH_SHORT).show());
                        } catch (Exception e) { runOnUiThread(() -> invokeAppDetails(item.packageOrPid)); }
                    }).start();
                    break;
                case 1: 
                    new Thread(() -> {
                        try {
                            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "pm disable-user --user 0 " + item.packageOrPid});
                            if (p.waitFor() != 0) throw new Exception();
                            runOnUiThread(() -> Toast.makeText(this, "已冻结", Toast.LENGTH_SHORT).show());
                        } catch (Exception e) { runOnUiThread(() -> { invokeAppDetails(item.packageOrPid); Toast.makeText(this, "请手动停用", Toast.LENGTH_SHORT).show(); }); }
                    }).start();
                    break;
                case 2: execCmd("pm enable " + item.packageOrPid, "已解冻启用"); break;
                case 3: if (item.sourceDir != null) execCmd("cp " + item.sourceDir + " /sdcard/Download/backup_" + item.packageOrPid + ".apk", "已备份"); break;
                case 4: execCmd("pm uninstall --user 0 " + item.packageOrPid, "已静默卸载"); break;
                case 5: if (item.sourceDir != null) execCmd("mount -o rw,remount /; rm -rf '" + item.sourceDir + "'; mount -o ro,remount /", "已物理删除，请重启"); break;
                case 6: execCmd("pm install-existing " + item.packageOrPid, "已恢复"); break;
                case 7: execCmd("pm grant " + item.packageOrPid + " android.permission.WRITE_SECURE_SETTINGS", "已尝试授权"); break;
                case 8: if (item.sourceDir != null) execCmd("mkdir -p /sdcard/Download/AppReverse/" + item.packageOrPid + " && cp " + item.sourceDir + " /sdcard/Download/AppReverse/" + item.packageOrPid + "/base.apk && cd /sdcard/Download/AppReverse/" + item.packageOrPid + " && unzip -o base.apk -d extracted/", "已解压"); break;
            }
        }).show();
    }

    private void invokeAppDetails(String packageName) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {}
    }

    private String escapeShellArg(String arg) { return arg.replace("'", "'\\''"); }

    private void showInputDialog(String title, String hint, final String cmdPrefix) {
        final EditText et = new EditText(this); et.setHint(hint);
        new AlertDialog.Builder(this).setTitle(title).setView(et).setPositiveButton("执行", (d, w) -> {
            String val = et.getText().toString().trim(); if (val.isEmpty()) return;
            try {
                if (cmdPrefix.equals("TEMP_FAKE")) execCmd("mount -o rw,remount /sys; for f in /sys/class/thermal/thermal_zone*/temp; do echo " + (Integer.parseInt(val)*1000) + " > $f 2>/dev/null; done; mount -o ro,remount /sys", "已尝试伪装温度");
                else if (cmdPrefix.equals("REGULATOR_FAKE")) execCmd("mount -o rw,remount /sys; for f in /sys/class/regulator/regulator.*/microamps; do echo " + (Integer.parseInt(val)*1000) + " > $f 2>/dev/null; done; mount -o ro,remount /sys", "已尝试调节电压");
                else if (cmdPrefix.equals("FPS_FAKE")) execCmd("settings put system min_refresh_rate " + Integer.parseInt(val) + " && settings put system peak_refresh_rate " + Integer.parseInt(val), "已改帧率");
                else if (cmdPrefix.equals("STORAGE_FAKE")) execCmd("setprop ro.product.storage_size '" + escapeShellArg(val) + "GB'", "已伪装存储");
                else if (cmdPrefix.equals("RAM_FAKE")) execCmd("setprop dalvik.vm.heapsize " + val + "m", "已修改堆上限");
                else execCmd(cmdPrefix + escapeShellArg(val) + "'", "已执行");
            } catch (NumberFormatException e) { Toast.makeText(MainActivity.this, "❌ 错误：请输入纯数字！", Toast.LENGTH_SHORT).show(); }
        }).setNegativeButton("取消", null).show();
    }

    private void checkBatteryHealth() {
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            try {
                Process pDump = Runtime.getRuntime().exec(new String[]{"su", "-c", "dumpsys batterystats 2>/dev/null | grep -E 'Capacity|Estimated' | head -n 5"});
                BufferedReader rDump = new BufferedReader(new InputStreamReader(pDump.getInputStream()));
                String dumpLine;
                while ((dumpLine = rDump.readLine()) != null) { if (dumpLine.contains("Capacity") || dumpLine.contains("Estimated")) sb.append(dumpLine.trim()).append("\n"); }
                String fStr = readFileAsRoot("/sys/class/power_supply/battery/charge_full");
                String dStr = readFileAsRoot("/sys/class/power_supply/battery/charge_full_design");
                if (fStr != null && dStr != null && !fStr.isEmpty() && !dStr.isEmpty()) {
                    try {
                        double full = Double.parseDouble(fStr.trim()); double design = Double.parseDouble(dStr.trim());
                        if (design > 0) { double health = (full / design) * 100; if (health > 100) health = 100; sb.append("\n👉 节点预估寿命: ").append(String.format("%.1f", health)).append("%"); }
                    } catch (NumberFormatException e) { sb.append("\n👉 节点数据格式异常。"); }
                } else sb.append("\n👉 无法读取节点数据。");
            } catch (Exception e) { sb.append("读取异常。"); }
            runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("电池健康度").setMessage(sb.toString()).setPositiveButton("OK", null).show());
        }).start();
    }

    private String readFileAsRoot(String path) {
        try { return new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(new String[]{"su", "-c", "cat " + path}).getInputStream())).readLine(); } catch (Exception e) { return null; }
    }

    private void showFormatWarning() {
        final EditText et = new EditText(this); et.setHint("输入 YES 开启倒计时");
        new AlertDialog.Builder(this).setTitle("⚠️ 极度危险 ⚠️").setMessage("将清空 /data 分区！").setView(et)
            .setPositiveButton("确认", (d, w) -> { if ("YES".equals(et.getText().toString().trim())) startFormatCountdown(); })
            .setNegativeButton("取消", null).show();
    }

    private void startFormatCountdown() {
        isFormatCancelled = false;
        final AlertDialog dialog = new AlertDialog.Builder(this).setTitle("自毁倒计时").setMessage("5秒后执行格式化...").setCancelable(false).create();
        dialog.setButton(DialogInterface.BUTTON_NEGATIVE, "紧急取消", (d, w) -> { isFormatCancelled = true; dialog.dismiss(); });
        dialog.show();
        new Thread(() -> {
            for (int i = 5; i > 0; i--) {
                if (isFormatCancelled) return;
                final int sec = i;
                try { Thread.sleep(1000); } catch (Exception e) {}
                runOnUiThread(() -> dialog.setMessage(sec + "秒后执行格式化..."));
            }
            if (!isFormatCancelled) { dialog.dismiss(); execCmd("sync && rm -rf /data/*", "自毁指令已执行"); }
        }).start();
    }

    private void forceMaxPower() {
        new AlertDialog.Builder(this).setTitle("芯片满血调度")
            .setPositiveButton("满血", (d, w) -> execCmd("mount -o rw,remount /sys; for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo performance > $cpu/cpufreq/scaling_governor 2>/dev/null; done; mount -o ro,remount /sys", "已尝试满血调度"))
            .setNeutralButton("恢复默认", (d, w) -> execCmd("mount -o rw,remount /sys; for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo schedutil > $cpu/cpufreq/scaling_governor 2>/dev/null; done; mount -o ro,remount /sys", "已尝试恢复默认")).show();
    }

    private void loadProcessesInBackground() {
        if (isProcessLoading) return;
        isProcessLoading = true;
        new Thread(() -> {
            try {
                Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "ps -A -o pid,name"});
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line; final List<AppItem> newProcs = new ArrayList<>();
                while ((line = reader.readLine()) != null) {
                    line = line.trim(); if (line.isEmpty() || line.startsWith("PID")) continue;
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        String pid = parts[0], pName = parts[1];
                        boolean exists = false;
                        for (AppItem item : dataList) if (!item.isProcess && item.packageOrPid.equals(pName)) { exists = true; break; }
                        if (!exists && !pName.equals("ps")) newProcs.add(new AppItem(pName, pid, true, false, null));
                    }
                }
                reader.close(); process.waitFor();
                runOnUiThread(() -> { dataList.addAll(newProcs); sortAndRefresh("进程 +" + newProcs.size() + "个"); isProcessLoading = false; });
            } catch (Exception e) { isProcessLoading = false; }
        }).start();
    }

    private void showModuleList() {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "ls /data/adb/modules"});
                BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line; final List<String> mods = new ArrayList<>();
                while ((line = reader.readLine()) != null) { line = line.trim(); if (!line.isEmpty() && !line.equals("lost+found")) mods.add(line); }
                p.waitFor();
                runOnUiThread(() -> {
                    if (mods.isEmpty()) Toast.makeText(this, "没有模块或无法访问", Toast.LENGTH_SHORT).show();
                    else new AlertDialog.Builder(this).setTitle("已安装模块").setItems(mods.toArray(new String[0]), (d, w) -> showModuleActions(mods.get(w))).show();
                });
            } catch (Exception e) {}
        }).start();
    }

    private void showModuleActions(final String modName) {
        new AlertDialog.Builder(this).setTitle("管理: " + modName).setItems(new String[]{"启用", "禁用", "彻底删除"}, (d, w) -> {
            if (w == 2) new AlertDialog.Builder(this).setTitle("二次确认").setMessage("彻底删除？").setPositiveButton("删除", (d2, w2) -> execCmd("rm -rf /data/adb/modules/" + modName, "已删除")).setNegativeButton("取消", null).show();
            else execCmd((w == 0) ? "rm -f /data/adb/modules/" + modName + "/disable" : "touch /data/adb/modules/" + modName + "/disable", "状态已修改");
        }).show();
    }

    private void execSysFileReplace() {
        new Thread(() -> {
            try {
                File temp = new File(getCacheDir(), "sysfile.tmp");
                InputStream is = getContentResolver().openInputStream(pendingSysFileUri); FileOutputStream fos = new FileOutputStream(temp);
                byte[] buf = new byte[8192]; int len; while ((len = is.read(buf)) > 0) fos.write(buf, 0, len); fos.close(); is.close();
                String cmd = "mount -o rw,remount /; cp " + temp.getAbsolutePath() + " " + pendingSysFilePath + "; chmod 644 " + pendingSysFilePath + "; mount -o ro,remount /";
                final int res = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd}).waitFor();
                runOnUiThread(() -> Toast.makeText(this, res == 0 ? "替换成功" : "失败", Toast.LENGTH_SHORT).show());
            } catch (Exception e) { try { Runtime.getRuntime().exec(new String[]{"su", "-c", "mount -o ro,remount /"}); } catch (Exception ex) {} }
        }).start();
    }

    private void setupAdBlock() {
        new AlertDialog.Builder(this).setTitle("广告拦截").setMessage("开启前会自动备份原 Hosts。")
            .setPositiveButton("开启", (d, w) -> execCmd("mount -o rw,remount /; [ ! -f /sdcard/Download/hosts.bak ] && cp /system/etc/hosts /sdcard/Download/hosts.bak; echo '127.0.0.1 doubleclick.net' > /system/etc/hosts; mount -o ro,remount /", "已开启"))
            .setNeutralButton("还原", (d, w) -> execCmd("mount -o rw,remount /; cp /sdcard/Download/hosts.bak /system/etc/hosts; mount -o ro,remount /", "已还原")).setNegativeButton("取消", null).show();
    }

    private void loadCpuCores() {
        cpuContainer.removeAllViews();
        File cpuDir = new File("/sys/devices/system/cpu");
        String[] files = cpuDir.list((dir, name) -> name.matches("cpu[0-9]+"));
        if (files != null) Arrays.sort(files, (a, b) -> Integer.compare(Integer.parseInt(a.replace("cpu", "")), Integer.parseInt(b.replace("cpu", ""))));
        int coreCount = (files != null) ? files.length : 8;
        for (int i = 0; i < coreCount; i++) {
            final int idx = Integer.parseInt(files != null ? files[i].replace("cpu", "") : String.valueOf(i));
            Button btn = new Button(this); btn.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            btn.setOnClickListener(v -> new Thread(() -> {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "cat /sys/devices/system/cpu/cpu" + idx + "/online"});
                    boolean isOn = !"0".equals(new BufferedReader(new InputStreamReader(p.getInputStream())).readLine().trim());
                    Runtime.getRuntime().exec(new String[]{"su", "-c", "echo " + (isOn ? "0" : "1") + " > /sys/devices/system/cpu/cpu" + idx + "/online"}).waitFor();
                    runOnUiThread(this::loadCpuCores);
                } catch (Exception e) {}
            }).start());
            cpuContainer.addView(btn);
            new Thread(() -> {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "cat /sys/devices/system/cpu/cpu" + idx + "/online"});
                    final boolean isOn = "1".equals(new BufferedReader(new InputStreamReader(p.getInputStream())).readLine().trim());
                    runOnUiThread(() -> { btn.setText("CPU" + idx + " : " + (isOn ? "🟢 运行" : "🔴 关闭")); btn.setBackgroundColor(isOn ? 0xFFE8F5E9 : 0xFFFFEBEE); });
                } catch (Exception e) {}
            }).start();
        }
    }

    private void runTerminalCmd() {
        String cmd = etTerminalInput.getText().toString().trim(); if (cmd.isEmpty()) return;
        tvTerminalOutput.append("\n$ " + cmd + "\n"); etTerminalInput.setText("");
        new Thread(() -> {
            try {
                ProcessBuilder pb = new ProcessBuilder("su", "-c", cmd); pb.redirectErrorStream(true); Process p = pb.start();
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line; final StringBuilder sb = new StringBuilder();
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
                p.waitFor();
                runOnUiThread(() -> { tvTerminalOutput.append(sb.toString()); ((ScrollView)findViewById(R.id.sv_terminal)).fullScroll(View.FOCUS_DOWN); });
            } catch (Exception e) { runOnUiThread(() -> tvTerminalOutput.append("Error: " + e.getMessage() + "\n")); }
        }).start();
    }

    private void execCmd(final String cmd, final String msg) {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                final int res = p.waitFor();
                runOnUiThread(() -> {
                    if (res == 0) Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
                    else Toast.makeText(this, "失败，请检查权限", Toast.LENGTH_LONG).show();
                    loadAppsOnly(); loadProcessesInBackground();
                });
            } catch (Exception e) { runOnUiThread(() -> Toast.makeText(this, "执行异常", Toast.LENGTH_SHORT).show()); }
        }).start();
    }

    private void loadAppsOnly() {
        new Thread(() -> {
            List<AppItem> apps = new ArrayList<>();
            for (ApplicationInfo appInfo : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
                apps.add(new AppItem(appInfo.loadLabel(pm).toString(), appInfo.packageName, false, (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0, appInfo.sourceDir));
            }
            runOnUiThread(() -> { dataList.clear(); dataList.addAll(apps); sortAndRefresh("应用已加载"); });
        }).start();
    }

    private void sortAndRefresh(String msg) {
        Collections.sort(dataList, (a, b) -> {
            if (a.isProcess != b.isProcess) return a.isProcess ? 1 : -1;
            if (a.isSystem != b.isSystem) return a.isSystem ? -1 : 1;
            return a.name.compareToIgnoreCase(b.name);
        });
        if (adapter == null) { adapter = new AppAdapter(); listView.setAdapter(adapter); } else adapter.notifyDataSetChanged();
        tvStatus.setText(msg + " | 共 " + dataList.size() + " 个");
    }
    
    private void extractBootImage() {
        new Thread(() -> {
            try {
                String[] paths = {"/dev/block/by-name/boot", "/dev/block/by-name/boot_a", "/dev/block/bootdevice/by-name/boot"};
                String successPath = null;
                for (String p : paths) { if (Runtime.getRuntime().exec(new String[]{"su", "-c", "ls " + p}).waitFor() == 0) { successPath = p; break; } }
                if (successPath != null) {
                    final int res = Runtime.getRuntime().exec(new String[]{"su", "-c", "mkdir -p /sdcard/Download/BootBackup && dd if=" + successPath + " of=/sdcard/Download/BootBackup/boot.img"}).waitFor();
                    runOnUiThread(() -> Toast.makeText(this, res == 0 ? "提取成功" : "提取失败", Toast.LENGTH_LONG).show());
                } else runOnUiThread(() -> Toast.makeText(this, "未找到Boot", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {}
        }).start();
    }

    private void disableSystemUpdates() {
        String[] pkgs = {"com.android.updater", "com.huawei.android.hwouc", "com.miui.updater", "com.google.android.gms.update", "com.samsung.android.sm_cn"};
        StringBuilder cmd = new StringBuilder();
        for (String pkg : pkgs) { cmd.append("[ \"$(pm path ").append(pkg).append(")\" != \"\" ] && pm disable-user --user 0 ").append(pkg).append("; "); }
        execCmd(cmd.toString(), "已尝试冻结系统更新");
    }

    private void toggleStatusBar() {
        new AlertDialog.Builder(this).setTitle("状态栏控制").setItems(new String[]{"隐藏", "恢复"}, (d, w) -> {
            if (w == 0) execCmd("settings put global policy_control immersive.status=*", "已隐藏"); else execCmd("settings put global policy_control null", "已恢复");
        }).show();
    }

    private void showResolutionDialog() {
        final EditText et = new EditText(this); et.setHint("输入如: 1080x1920");
        new AlertDialog.Builder(this).setTitle("调节分辨率").setView(et)
            .setPositiveButton("修改", (d, w) -> { if (et.getText().toString().contains("x")) execCmd("wm size " + et.getText().toString(), "已修改"); })
            .setNeutralButton("恢复默认", (d, w) -> execCmd("wm size reset", "已恢复")).setNegativeButton("取消", null).show();
    }

    private void selectFile(int reqCode, String type) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT); intent.setType(type); startActivityForResult(intent, reqCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == 100) new AlertDialog.Builder(this).setTitle("刷入模块").setMessage("确定刷入？").setPositiveButton("刷入", (d, w) -> installModuleFromUri(data.getData())).setNegativeButton("取消", null).show();
            else if (requestCode == 101) {
                pendingSysFileUri = data.getData();
                final EditText et = new EditText(this); et.setHint("/system/etc/hosts");
                new AlertDialog.Builder(this).setTitle("替换系统文件").setMessage("目标路径:").setView(et)
                    .setPositiveButton("确认", (d, w) -> { pendingSysFilePath = et.getText().toString().trim(); if (!pendingSysFilePath.isEmpty()) execSysFileReplace(); }).setNegativeButton("取消", null).show();
            }
        }
    }

    private void installModuleFromUri(final Uri uri) {
        new Thread(() -> {
            try {
                File temp = new File(getCacheDir(), "module.zip");
                InputStream is = getContentResolver().openInputStream(uri); FileOutputStream fos = new FileOutputStream(temp);
                byte[] buf = new byte[8192]; int len; while ((len = is.read(buf)) > 0) fos.write(buf, 0, len); fos.close(); is.close();
                final int res = Runtime.getRuntime().exec(new String[]{"su", "-c", "magisk --install-module " + temp.getAbsolutePath()}).waitFor();
                runOnUiThread(() -> Toast.makeText(this, res == 0 ? "刷入成功" : "刷入失败", Toast.LENGTH_LONG).show());
            } catch (Exception e) {}
        }).start();
    }

    class AppAdapter extends BaseAdapter {
        public int getCount() { return dataList.size(); }
        public Object getItem(int p) { return dataList.get(p); }
        public long getItemId(int p) { return p; }
        public View getView(int p, View v, ViewGroup g) {
            if (v == null) v = getLayoutInflater().inflate(R.layout.item_app, null);
            AppItem it = dataList.get(p);
            TextView n = v.findViewById(R.id.tv_app_name), pkg = v.findViewById(R.id.tv_package_name);
            ImageView ico = v.findViewById(R.id.iv_icon);
            if (it.isProcess) {
                n.setTextColor(0xFF1976D2); n.setText("[进程] " + it.name + " [Root Only]"); pkg.setText("PID: " + it.packageOrPid); ico.setImageResource(android.R.drawable.sym_def_app_icon);
            } else {
                Drawable icon = iconCache.get(it.packageOrPid);
                if (icon == null) {
                    try { icon = pm.getApplicationIcon(it.packageOrPid); iconCache.put(it.packageOrPid, icon); } 
                    catch (Exception e) { icon = getResources().getDrawable(android.R.drawable.sym_def_app_icon); }
                }
                ico.setImageDrawable(icon);
                n.setTextColor(it.isSystem ? 0xFFD32F2F : 0xFF000000); n.setText((it.isSystem ? "[系统] " : "") + it.name + " [Root Only]"); pkg.setText(it.packageOrPid);
            }
            return v;
        }
    }
}
